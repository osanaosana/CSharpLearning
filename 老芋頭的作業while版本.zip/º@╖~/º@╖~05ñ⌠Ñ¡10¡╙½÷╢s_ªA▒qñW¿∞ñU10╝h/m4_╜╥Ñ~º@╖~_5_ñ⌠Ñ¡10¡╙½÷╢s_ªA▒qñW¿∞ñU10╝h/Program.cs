﻿using System;
using System.Windows.Forms;
using System.Drawing;
static class Program
{
  static void Main()
  {

        // fix #9  
        //  之前第二個homework已示範展示了從左到右展現共 10 個按鈕(這樣算一層)
        //          煩請用 while 做出來 水平從左到右展現共10個按鈕
        //          但是要做 10 層
        Form f = new Form();
        f.Size = new Size(530, 530);
        // fix #1 執行此程式, 觀察跑出的視窗上面有什麼?
        // fix #2 將下行註解取消, 再執行此程式, 觀察跑出的視窗上面有什麼?
        // fix #3 將下行的20改成60 , 再執行此程式, 觀察跑出的視窗上面有什麼?
        // fix #4 將下行的60改成100 , 再執行此程式, 觀察跑出的視窗上面有什麼?
        // fix #5 再將下行註解
        // Program.以xy座標加個按鈕到Form上(10, 20, f);

        // fix #7 已示範展示了從左到右展現共 3 個按鈕
        // ,煩請用 while 做出來 水平從左到右展現共10個按鈕

        // fix #8 再將下三行註解
        // fix #6 再將下三行註解取消
        // Program.以xy座標加個按鈕到Form上(10, 20 + 20, f);
        // Program.以xy座標加個按鈕到Form上(10  , 20 + 60, f);
        // Program.以xy座標加個按鈕到Form上(10, 20 + 100, f);

        int x = 0, y = 0;

        int xt = 0, yt = 0;


        while ( yt < 10)
        {
            while (xt < 10)
            {
                Program.以xy座標加個按鈕到Form上(10 + x, 20 + y, f);
                ++xt;
                x += 40;
            }
            xt = 0;
            x = 0;

            ++yt;
            y += 40;
        }

        

        Application.Run(f);
    }
    static Button 以xy座標加個按鈕到Form上(int x, int y, Form f)
    {
        Point location = new Point(x, y);
        Button b = new Button();
        b.Location = location;
        b.BackColor = Color.Yellow;
        b.Text = "炸";
        b.AutoSize = true;
        b.AutoSizeMode = AutoSizeMode.GrowAndShrink;
        f.Controls.Add(b);
        return b;
    }
}