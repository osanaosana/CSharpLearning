﻿using System;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine();
        Random rn = new Random();
        int x;
        //  fix #1 觀察下一行
        // d 為 0.0 和 1.0 (不包含1.0) 之間的亂數
        double d = rn.NextDouble();
        Console.WriteLine();
        //  fix #2 觀察下一行
        Console.WriteLine("d 為 " + d);
        Console.WriteLine();
        Console.Write(" x 的值 是 ");

        //  fix #3 如何讓使得 x 存有 6 或 7 的值
        //  請寫在下面 
        x = 6 + (int)(d * 2);
        Console.WriteLine(x);
        Console.WriteLine("##########################");
        //  fix #4 如何讓使得 x 存有 6 的值時,印出 x為偶數
        //                 而 x 存有 7 的值時,印出 x為奇數
        //  請寫在下面

        string result = "";

        result = (x % 2 == 0) ? "x為偶數" : "x為奇數";

        Console.WriteLine("??????????????????????????");
        Console.WriteLine(result);

        Console.WriteLine("結束請按 y , 按任意鍵繼續測試");

        while (Console.ReadKey().KeyChar != 'y')
        {
            Console.Clear();
            d = rn.NextDouble();
            Console.WriteLine();
            Console.WriteLine("d 為 " + d);
            Console.WriteLine();
            Console.Write(" x 的值 是 ");
            x = 6 + (int)(d * 2);
            Console.WriteLine(x);
            result = (x % 2 == 0) ? "x為偶數" : "x為奇數";

            Console.WriteLine("??????????????????????????");
            Console.WriteLine(result);
            Console.WriteLine();

            Console.WriteLine("結束請按 y , 按任意鍵繼續測試");
        }

        Console.WriteLine("結束");
        Console.WriteLine(); Console.WriteLine(); Console.WriteLine();
        Console.WriteLine();

    }
}
