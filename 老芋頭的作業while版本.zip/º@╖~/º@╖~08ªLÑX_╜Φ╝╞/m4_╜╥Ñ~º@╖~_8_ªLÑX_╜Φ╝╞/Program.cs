﻿using System;
class Program {
    
 static void Main(string[] args) {
      Console.ForegroundColor = ConsoleColor.Yellow;
      Console.WriteLine("開始"); 
      int x;
      int y;
//  fix #1  如何把 6 到15 共 拾 個整數, 判斷其是否為質數
//    , 如果是質數, 把它印出來
//  請寫在下面

      
        Console.Write("6 到15 的質數有: ");
        //while版本
        x = 6;
        y = 15;
        while (x <= y)
        {
            bool xIsTrue = true;
            int i = 2;
            while (i < x)
            {
                if (x % i == 0)
                {
                    xIsTrue = false;
                    break;
                }
                ++i;
            }

            if (xIsTrue)
            {
                Console.Write(x + "  ");
            }
            ++x;
        }


        Console.WriteLine();
        Console.Write("6 到15 的質數有: ");
        //for版本
        for (x = 6, y= 15; x <= y; ++x)
        {
            bool xIsTrue = true; 
            for (int i = 2; i < x; ++i)
            {
                if (x % i == 0)
                {
                    xIsTrue = false;
                    break;
                }
            }

            if (xIsTrue)
            {
                Console.Write(x + "  ");
            }
        }

        Console.WriteLine();
        Console.WriteLine("============");

        // 比如 x 為 6, 則用 2, 3, 4, 5  ( 即比 x 少 1 ) 當除數去除它, 若都無法整除
        //   , 則其為質數, 可惜2及3當除數去除它, 都可以整除

        //y = 7;
// 比如 y 為 7, 則用 2, 3, 4, 5, 6 ( 即比 y 少 1 ) 當除數去除它, 若都無法整除
//   , 則其為質數, 結果真的都無法整除

      //Console.WriteLine(y + "為質數");

      Console.WriteLine("結束");
        Console.ReadLine();
    }
 }