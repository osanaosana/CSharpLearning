﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShowTree
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("耶誕樹5層:");
            Console.WriteLine();

            //while版本
            int sp = 4, star = 1;
            while (sp >= 0)
            {
                int i = 0;
                while (i < sp)
                {
                    Console.Write(" ");
                    ++i;
                }

                i = 0;
                while (i < star)
                {
                    Console.Write("*");
                    ++i;
                }
                Console.WriteLine();

                --sp;
                star += 2;
            }

            Console.WriteLine();
            Console.WriteLine();

            //以下是for版本
            for (sp = 4,star = 1; sp >= 0; --sp, star +=2 )
            {

                for (int i = 0; i < sp; ++i)
                {
                    Console.Write(" ");
                }
                for (int i = 0; i < star; ++i)
                {
                    Console.Write("*");
                }
                Console.WriteLine();

            }


            Console.WriteLine();
            Console.WriteLine();

            //更簡潔的寫法
            for (sp = 4, star = 1; sp >= 0; --sp, star += 2)
            {
                string output = "";

                output = output.PadRight(sp, ' ').PadRight(sp + star, '*');
                Console.WriteLine(output);

            }

            Console.ReadLine();
        }
    }
}
